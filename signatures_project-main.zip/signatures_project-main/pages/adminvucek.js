/* eslint-disable */

import SignatureCanvas from "react-signature-canvas";
import { useCallback, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { AnimatedSVG } from "../lib/components/animated-svg-2";

const pushToServer = async (data) => {
  return fetch("/api/push", { method: "POST", body: JSON.stringify({ data }) });
};

const deleteFromServer = async (data) => {
  return fetch("/api/delete/" + data.id, { method: "DELETE" });
};

const getEntries = async (page = 1) => {
  return fetch(`/api/entries-2?page=${page}`, { method: "GET" }).then((res) =>
    res.json()
  );
};

export default function Home() {
  const ref = useRef();
  const [exported, setExported] = useState();
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();
  const entries = useQuery(["entries", `page-${page}`], () => getEntries(page));
  const pushEntry = useMutation(pushToServer, {
    onSuccess: () => queryClient.invalidateQueries("entries"),
  });
  const deleteEntry = useMutation(deleteFromServer, {
    onSuccess: () => queryClient.invalidateQueries("entries"),
  });

  const handleExport = () => {
    const image = ref.current.toDataURL("image/svg+xml");
    ref.current.clear();
    pushEntry.mutate(image);
    setExported(image);
  };

  const handleDelete = (id) => {
    if (confirm("You sure you want to delete this?")) {
      deleteEntry.mutate({ id });
    }
  };

  return (
    <div>
      <h1>Add Entry</h1>
      <SignatureCanvas
        ref={ref}
        penColor="white"
        canvasProps={{
          width: 1000,
          height: 400,
          className: "sigCanvas",
        }}
        backgroundColor="black"
      />
      <button onClick={handleExport}>Add</button>

      <h1>Current entries</h1>

      {entries.isFetched &&
        entries.data.entries &&
        entries.data.entries.map((entry) => (
          <>
            <AnimatedSVG content={entry} />
            <div>
              <button onClick={() => handleDelete(entry.id)}>
                Remove entry #{entry.id}
              </button>
            </div>
          </>
        ))}
             <div>
        <p>
          Viewing page {page} of {entries.data && entries.data.pages}
          <div style={{ display: "inline-block", marginLeft: 10 }}>
            <button
              onClick={() => {
                setPage(page - 1);
              }}
              disabled={page === 1}
            >
              {"<<"} Prev
            </button>
            <button
              onClick={() => {
                setPage(page + 1);
              }}
              disabled={!entries.isFetched || entries.data.pages <= page}
            >
              Next {">>"}
            </button>
          </div>
        </p>
      </div>
    </div>
  );
}
