import db from "../../lib/db";

/**
 * @param {import("next").NextApiRequest} req
 * @param {import("next").NextApiResponse} res
 */
const handler = async (req, res) => {
  if (req.method !== "GET")
    return res.status(405).send({ error: "not_allowed" });

  /* 
  
  try {
    const entries = await db.drawing.findMany({ orderBy: { id: "desc" } });
    
  */

  try {
    const count = await db.drawing.count();
    const skip = Math.floor(Math.random() * count);
    const entries = await db.drawing.findMany({
      take: 7,
      skip: skip,
      orderBy: { id: "desc" },
    });
    const created = await (req.query.cid && req.query.cid !== "none"
      ? db.drawing.findFirst({
          where: { id: { equals: parseInt(req.query.cid, 10) } },
        })
      : Promise.resolve(undefined));

    return res.json({ entries, created });
  } catch (err) {
    console.log({ err });
    return res.status(500).json({ error: "unknown" });
  }
};

export default handler;
