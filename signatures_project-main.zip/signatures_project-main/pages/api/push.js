import db from "../../lib/db";

/**
 * @param {import("next").NextApiRequest} req
 * @param {import("next").NextApiResponse} res
 */
const handler = async (req, res) => {
  if (req.method !== "POST")
    return res.status(405).send({ error: "not_allowed" });

  try {
    const data = JSON.parse(req.body).data;
    const result = await db.drawing.create({ data: { data } });

    return res.json(result);
  } catch (err) {
    console.log({ err });
    return res.status(500).json({ error: "unknown" });
  }
};

export default handler;
