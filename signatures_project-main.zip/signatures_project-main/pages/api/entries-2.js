import db from "../../lib/db";

const PER_PAGE_ITEMS = 10;

/**
 * @param {import("next").NextApiRequest} req
 * @param {import("next").NextApiResponse} res
 */
const handler = async (req, res) => {
  if (req.method !== "GET")
    return res.status(405).send({ error: "not_allowed" });

  const { page = 1 } = req.query;
  const limit = PER_PAGE_ITEMS;
  const skip = PER_PAGE_ITEMS * (page - 1);

  try {
    const count = await db.drawing.count();
    const pages = Math.ceil(count / PER_PAGE_ITEMS);
    const entries = await db.drawing.findMany({
      orderBy: { id: "desc" },
      take: limit,
      skip,
    });

    return res.json({ entries, pages });
  } catch (err) {
    console.log({ err });
    return res.status(500).json({ error: "unknown" });
  }
};

export default handler;
