import db from "../../../lib/db";

/**
 * @param {import("next").NextApiRequest} req
 * @param {import("next").NextApiResponse} res
 */
const handler = async (req, res) => {
  if (req.method !== "DELETE")
    return res.status(405).send({ error: "not_allowed" });

  const { id } = req.query;
  try {
    await db.drawing.delete({ where: { id: parseInt(id, 10) } });

    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: "unknown" });
  }
};

export default handler;
