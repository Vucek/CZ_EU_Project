/* eslint-disable */

import Link from "next/link";
import { useQuery } from "react-query";
import { AnimatedSVG } from "../lib/components/animated-svg";
import { useRouter } from "next/router";
import Head from "next/head";

const getEntries = async (createdId) => {
  return fetch(`/api/entries?cid=${createdId || "none"}`, {
    method: "GET",
  }).then((res) => res.json());
};

export default function Home() {
  const router = useRouter();
  const createdId = router.query.cid;
  const entries = useQuery(["entries", createdId], () => getEntries(createdId));
  const loading = "Načítá se...";
  const loadingAction = "vucek";
 
  return (
    <div>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta property="og:image" content="https://pf2022.vercel.app/ogimage2.png" />
        <meta property="og:title" content="UMPRUM PF 2022" />
        <meta property="og:description" content="Interactive PF 2022 from The Academy of Arts, Architecture and Design in Prague." />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@UMPRUMKA" />
        <meta name="twitter:creator" content="@Vucek" />
        <meta name="twitter:title" content="UMPRUM PF 2022" />
        <meta name="twitter:description" content="Interactive PF 2022 from The Academy of Arts, Architecture and Design in Prague." />
        <meta name="twitter:image" content="https://pf2022.vercel.app/twitterimage.png" />
        <title>UMPRUM PF 2022</title>
      </Head>
      <style jsx global>{`
        div {
          width: 100%;
          height: 100%;
        }
        body {
          width: 100%;
          height: 100%;
          max-width: 100%;
          max-height: 100%;
          overflow: hidden;
        }
        html {
          width: 100%;
          height: 100%;
          max-width: 100%;
          max-height: 100%;
          overflow: hidden;
        }
        .link {
          position: absolute;
          top: 64px;
          left: 24px;
          font-size: 18px;
          color: blue;
          z-index: 10000;
          text-decoration: underline;
          text-decoration-color: blue;
        }
        .generate {
          position: relative;
          font-size: 18px;
          color: blue;
          z-index: 10000;
          text-decoration: underline;
          text-decoration-color: blue;
        }
        .vucek {
          position: absolute;
          top: 64px;
          left: 24px;
          font-size: 18px;
          color: blue;
          text-decoration: none;
          text-decoration-color: blue;
        }
        a {
          position: absolute;
          top: 24px;
          left: 24px;
          font-size: 18px;
          color: blue;
          margin: 0px;
          padding: 0px;
          z-index: 10000;
          text-decoration: none;
        }
        .link:hover {
          position: absolute;
          top: 64px;
          left: 24px;
          font-size: 18px;
          color: blue;
          margin: 0px;
          padding: 0px;
          z-index: 10000;
          text-decoration: none;
        }
      `}</style>
      <Link href="index"><a>UMPRUM PF 2022</a></Link>
      <br />
      <Link href="pad">


        <a className="link">Přidejte vlastní vzkaz</a>
      </Link>
      {entries.isFetched &&
        entries.data &&
        entries.data.entries.map((entry) => <AnimatedSVG content={entry} />)}
      {entries.isFetched && entries.data && entries.data.created && (
        <AnimatedSVG createdByUser content={entries.data.created} />
      )}
    </div>
  );
}
