/* eslint-disable */

import SignatureCanvas from "react-signature-canvas";
import { useRef, useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { AnimatedSVG } from "../lib/components/animated-svg";
import Link from "next/link";
import { useRouter } from "next/router";
import Head from "next/head";


const pushToServer = async (data) => {
  return fetch("/api/push", { method: "POST", body: JSON.stringify({ data }) });
};

const getEntries = async (data) => {
  return fetch("/api/entries", { method: "GET" }).then((res) => res.json());
};

export default function Home() {
  const router = useRouter();
  const ref = useRef();
  const [exported, setExported] = useState();
  const queryClient = useQueryClient();
  const entries = useQuery("entries", getEntries);
  const pushEntry = useMutation(pushToServer, {
    onSuccess: () => queryClient.invalidateQueries("entries"),
  });

  const handleExport = async (e, path) => {
    e.preventDefault();
    const image = ref.current.toDataURL("image/svg+xml");
    ref.current.clear();
    console.log({ image });
    const result = await pushEntry.mutateAsync(image);
    const { id } = await result.json();
    setExported(image);

    if (path === "index") {
      setTimeout(function () {
        router.push({ pathname: "/", query: { cid: id } });
      }, 300);
    }
  };

  const size = useWindowSize();

  return (
    <div>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta property="og:image" content="https://pf2022.vercel.app/ogimage2.png" />
        <meta property="og:title" content="UMPRUM PF 2022" />
        <meta property="og:description" content="Interactive PF 2022 from The Academy of Arts, Architecture and Design in Prague." />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <title>UMPRUM PF 2022</title>
      </Head>
      <style jsx global>{`
        div {
          width: 100%;
        }

        body {
          overflow: hidden;
        }

        a {
          position: absolute;
          font-size: 18px;
          top: 64px;
          left: 24px;
          color: white;
          text-decoration: underline;
          text-decoration-color: white;
        }
        
        a:hover {
          position: absolute;
          font-size: 18px;
          top: 64px;
          left: 24px;
          color: white;
          text-decoration: none;
        }

        .back {
          position: absolute;
          left: 272px;
          color: white;
        }

        .retry {
          position: absolute;
          left: 192px;
          color: white;
        }
        
        .retry:hover {
          position: absolute;
          left: 192px;
          color: white;
          text-decoration: none;
        }
        
        .back:hover {
          position: absolute;
          font-size: 18px;
          left: 272px;
          color: white;
          text-decoration: none;
        }

        p {
          position: absolute;
          top: 24px;
          left: 24px;
          font-size: 18px;
          color: white;
          margin: 0px;
          padding: 0px;
        }

        html {
          width: 100%;
          height: 100%;
          background-color: blue;
          overflow: hidden;
        }
      `}</style>
      <p>Co si přejete do roku 2022?</p>
      <br />
      <Link href="pad">
        <a onClick={(e) => handleExport(e, "index")}>Uložit do PF</a>
      </Link>
      <Link href="pad">
        <a
          className="retry"
          onClick={() => {
            window &&
              window.location.reload(); /* <-- this will trigger a reload */
          }}
        >
          Smazat
        </a>
      </Link>
      <Link href="index">
        <a className="back">Domů</a>
      </Link>

      <SignatureCanvas
        ref={ref}
        penColor="white"
        canvasProps={{
          width: size.width,
          height: size.height,
          className: "sigCanvas",
        }}
        backgroundColor="blue"
      />
    </div>
  );
}

function useWindowSize() {
  // Initialize state with undefined width/height so server and client renders match
  // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
  const [windowSize, setWindowSize] = useState({
    width: undefined,
    height: undefined,
  });

  useEffect(() => {
    // only execute all the code below in client side
    if (typeof window !== "undefined") {
      // Handler to call on window resize
      function handleResize() {
        // Set window width/height to state
        setWindowSize({
          width: window.innerWidth,
          height: window.innerHeight,
        });
      }

      // Add event listener
      window.addEventListener("resize", handleResize);

      // Call handler right away so state gets updated with initial window size
      handleResize();

      // Remove event listener on cleanup
      return () => window.removeEventListener("resize", handleResize);
    }
  }, []); // Empty array ensures that effect is only run on mount
  return windowSize;
}
